﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NotePad
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void novoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rchTxtBxConteudo.Clear();
        }

        private void abrirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdl = new OpenFileDialog();
            fdl.Title = "Abra seu arquivo";
            fdl.Filter = "Documento de texto(*.txt)|*.txt|Todos os arquivos(*.txt)|*.*";
            if (fdl.ShowDialog() == DialogResult.OK)
                rchTxtBxConteudo.LoadFile(fdl.FileName, RichTextBoxStreamType.PlainText);
            this.Text = fdl.FileName;



        }

        private void salvarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sv = new SaveFileDialog();
            sv.Title = "Salvar seu arquivo";
            sv.Filter = "Documento de texto(*.txt)|*.txt|Todos os arquivos(*.txt)|*.*";
            if (sv.ShowDialog() == DialogResult.OK)
                rchTxtBxConteudo.SaveFile(sv.FileName, RichTextBoxStreamType.PlainText);
            this.Text = sv.FileName;
        }

        private void salvarEmToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog sv = new SaveFileDialog();
            sv.Title = "Salvar seu arquivo";
            sv.Filter = "Documento de texto(*.txt)|*.txt|Todos os arquivos(*.txt)|*.*";
            if (sv.ShowDialog() == DialogResult.OK)
                rchTxtBxConteudo.SaveFile(sv.FileName, RichTextBoxStreamType.PlainText);
            this.Text = sv.FileName;
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void copiarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rchTxtBxConteudo.Copy();
        }

        private void recortarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rchTxtBxConteudo.Cut();
        }

        private void colarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rchTxtBxConteudo.Paste();
        }

        private void desfazerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rchTxtBxConteudo.Undo();
        }

        private void refazerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rchTxtBxConteudo.Redo();
        }

        private void selecionarTudoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rchTxtBxConteudo.SelectAll();
        }

        private void selecionarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rchTxtBxConteudo.Select();
        }

        private void deletarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rchTxtBxConteudo.Clear();
        }

        private void preferenciasToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void dataHoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string s = Convert.ToString(DateTime.Now);
            rchTxtBxConteudo.Text = rchTxtBxConteudo + s;
        }

        private void fonteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fnt = new FontDialog();
            if (fnt.ShowDialog() == DialogResult.OK)
                rchTxtBxConteudo.Font = fnt.Font;

        }

        private void corToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ColorDialog clr = new ColorDialog();
            if (clr.ShowDialog() == DialogResult.OK)
                rchTxtBxConteudo.ForeColor = clr.Color;
        }
    }
}
